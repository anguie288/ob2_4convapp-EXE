//
//  ViewController.m
//  ob2_4convapp | EXE
//
//  Created by Angela on 2020-04-09.
//  Copyright © 2020 angela. All rights reserved.
//

#import "ViewController.h"

double convertfoot (double unitone) {
    double unito;
    unito = unitone * 0.032808;
    return unito;
}

double convertmeters (double unittwo){
    double unitmet;
    unitmet = unittwo/100;
    return unitmet;
}


double convertinch (double unitthree){
    double unitinch;
    unitinch = unitthree*0.39370;
    return unitinch;
}


@interface ViewController ()

@property (weak, nonatomic) IBOutlet UITextField *input;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segment;

@property (weak, nonatomic) IBOutlet UILabel *output;

@end

@implementation ViewController

- (IBAction)update:(id)sender {
    
    NSMutableString *buf = [NSMutableString new];
    
    double userinp = [self.input.text doubleValue];
    
    if (self.segment.selectedSegmentIndex ==0) {
        double unitones = convertfoot(userinp);
        NSString *dou = [NSString stringWithFormat:@"%lf",unitones];
        [buf appendString: dou];[buf appendString: @" feet"];
        }
    else if (self.segment.selectedSegmentIndex ==1) {
        double unittwo = convertmeters(userinp);
        NSString *dou = [NSString stringWithFormat:@"%lf",unittwo];
        [buf appendString: dou];[buf appendString: @" meters"];
        }
    else {
        double unitth = convertinch(userinp);
        /*NSString *dou = [NSString stringWithFormat:@"%lf",unitth];*/
        NSNumber *myDoubleNumber = [NSNumber numberWithDouble:unitth];

        //[myDoubleNumber stringValue];
        [buf appendString: [myDoubleNumber stringValue]];[buf appendString: @" inches"];
        //[buf appendString:@"unit three"];
        }
        
        self.output.text = buf;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[UISegmentedControl appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont fontWithName:@"STHeitiSC-Medium" size:20.0], NSFontAttributeName, nil] forState:UIControlStateNormal];
    
    
    // Do any additional setup after loading the view.
}



@end
